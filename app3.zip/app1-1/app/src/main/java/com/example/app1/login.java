package com.example.app1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class login extends AppCompatActivity {
    EditText usrn, pass;
    DBHelper db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        db = new DBHelper(this);
    }

    public void userRegistered(View view) {
        Intent intent = new Intent(login.this, register.class);
        startActivity(intent);
    }

    public void userLogin(View view) {

        usrn = findViewById(R.id.editTextTextEmailAddress2);
        pass = findViewById(R.id.editTextTextPassword);

        String username = usrn.getText().toString();
        String password = pass.getText().toString();
//
//        String gotuser = db.getname(username, password);
//        Toast.makeText(this, "Got you", Toast.LENGTH_SHORT).show();
        if (username.equals("") || password.equals("")) {
            Toast.makeText(this, "again null", Toast.LENGTH_SHORT).show();
        } else {
            boolean check = db.loginuser(username, password);
            if (check == true) {
//                Intent intent = new Intent(this, userHome.class);
//                intent.putExtra("STRING_MESSAGE", gotuser);
//                startActivity(intent);

                Toast.makeText(this, "Logged IN", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "LOGIN FAILED", Toast.LENGTH_SHORT).show();

            }

        }
    }
}