package com.example.app1;


import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {
    public static final String DBNAME = "project_db";

    public DBHelper(Context context) {
        super(context, "project_db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase myDB) {
        myDB.execSQL("create table skills(Mail TEXT, Skill TEXT)");
        myDB.execSQL("create table users(Name TEXT, Mail TEXT PRIMARY KEY, Password TEXT, Contact TEXT)");
    }


    @Override
    public void onUpgrade(SQLiteDatabase myDB, int i, int i1) {
        myDB.execSQL("DROP TABLE IF EXISTS users");
        onCreate(myDB);
    }

    public boolean insertData(String Name,String Mail, String Password, List<String> Skills, String Number){
        SQLiteDatabase myDb = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put("Name",Name);
        cv.put("Mail", Mail);
        cv.put("Password",Password);
        cv.put("Contact", Number);

        long result = myDb.insert("users",null,cv);

        if(result == -1){
            return false;
        }else{

            for (String skill : Skills) {
                ContentValues cv2 = new ContentValues();
                cv2.put("Mail", Mail);
                cv2.put("Skill", skill);
                long result2 = myDb.insert("skills", null, cv2);
                if(result2 == -1){
                    return false;
                }
            }
            return true;
        }
    }
    public boolean insertUserSkills(String Mail, String Skill) {
        SQLiteDatabase myDb = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put("Mail", Mail);
        cv.put("Skill", Skill);

        long result = myDb.insert("skills", null, cv);

        if (result == -1) {
            return false;
        } else {
            return true;
        }
    }

    public boolean loginuser(String un,String up){
        SQLiteDatabase myDb = this.getWritableDatabase();
        Cursor cursor = myDb.rawQuery("SELECT * FROM users WHERE Mail = ? AND Password = ?", new String[]{un,up});
        try {
            if (cursor.getCount() > 0) {
                return true;
            } else {
                return false;
            }
        } finally {
            cursor.close();
        }
    }

    @SuppressLint("Range")
    public String getname(String un, String up) {
        SQLiteDatabase mydb = this.getReadableDatabase();
        String[] columns = {"Name"};
        String selection = "Mail = ? AND Password = ?";
        String[] selectionArgs = {un, up};
        Cursor cursor = mydb.query("users", columns, selection, selectionArgs, null, null, null);
        try {
            if (cursor.moveToFirst()) {
                return cursor.getString(cursor.getColumnIndex("Name"));
            } else {
                return null;
            }
        } finally {
            cursor.close();
        }
    }

    public List<String> getMatchingUsers(String projectType, List<String> requiredSkills) {
        SQLiteDatabase mydb = this.getReadableDatabase();
        List<String> matchingUsers = new ArrayList<>();

        String[] columns = {"Mail"};
        String selection = "Mail IN (SELECT Mail FROM skills WHERE Skill = ?)";
        for (int i = 1; i < requiredSkills.size(); i++) {
            selection += " AND Mail IN (SELECT Mail FROM skills WHERE Skill = ?)";
        }

        String[] selectionArgs = new String[requiredSkills.size()];
        for (int i = 0; i < requiredSkills.size(); i++) {
            selectionArgs[i] = requiredSkills.get(i);
        }

        Cursor cursor = mydb.query("skills", columns, selection, selectionArgs, null, null, null);
        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") String mail = cursor.getString(cursor.getColumnIndex("Mail"));
                Cursor cursor2 = mydb.rawQuery("SELECT * FROM users WHERE Mail = ? AND EXISTS (SELECT 1 FROM skills WHERE Mail = ? AND Skill = ?)", new String[]{mail, mail, projectType});
                if (cursor2.moveToFirst()) {
                    @SuppressLint("Range") String name = cursor2.getString(cursor2.getColumnIndex("Name"));
                    matchingUsers.add(name);
                }
                cursor2.close();
            } while (cursor.moveToNext());
        }
        cursor.close();

        return matchingUsers;
    }


}
