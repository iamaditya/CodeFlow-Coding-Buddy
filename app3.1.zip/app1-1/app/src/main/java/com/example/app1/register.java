package com.example.app1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class register extends AppCompatActivity {
    DBHelper Dbx;
    EditText uname,umail,upass,uskills,ucontact;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
    }

    public void registerme(View view) {

        Dbx = new DBHelper(this);

        uname = findViewById(R.id.editTextText);
        umail = findViewById(R.id.editTextTextEmailAddress2);
        upass = findViewById(R.id.editTextTextPassword);
        uskills = findViewById(R.id.editTextTextPersonName3);
        ucontact = findViewById(R.id.editTextTextPersonName4);

        String xname = uname.getText().toString();
        String xemail = umail.getText().toString();
        String xpassword = upass.getText().toString();
        String xcontact = ucontact.getText().toString();
//        String xskills = uskills.getText().toString();

        String xskillsStr = uskills.getText().toString().trim();

        List<String> xskills = new ArrayList<>(Arrays.asList(xskillsStr.split(",")));

//        List<String> xskills = new ArrayList<>(Arrays.asList(uskills.trim().split(",")));

        if (xname.equals("") || xemail.equals("") || xpassword.equals("") || xskills.equals("")) {
            Toast.makeText(this, "We don't accept NULL input", Toast.LENGTH_SHORT).show();
        } else {
            boolean b = Dbx.insertData(xname, xemail, xpassword,xskills,xcontact);
            if (b == true) {
                // Insert user's skills into the database
                for (String skill : xskills) {
                    boolean s = Dbx.insertUserSkills(xemail, skill);
                    if (s == false) {
                        Toast.makeText(this, "Found some error", Toast.LENGTH_SHORT).show();
                        return;
                    }
                }
            }
//            Toast.makeText(this, "Registered", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(register.this, login.class);
            startActivity(intent);
        }
    }
}